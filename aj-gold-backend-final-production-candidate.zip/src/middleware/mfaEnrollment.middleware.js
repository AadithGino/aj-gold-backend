const jwt = require("jsonwebtoken");
const User = require("../models/user.model");
const ApiError = require("../utils/ApiError");
const { JWT_SECRET, JWT_ISSUER, JWT_AUDIENCE } = require("../config/env");
const { USER_ROLES } = require("../constants/enums");

const mfaEnrollmentMiddleware = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith("Bearer ")) {
      throw new ApiError(401, "MFA enrollment token is required.");
    }

    const token = header.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET, {
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE,
    });

    if (decoded.purpose !== "mfa-enrollment") {
      throw new ApiError(401, "Invalid MFA enrollment token.");
    }

    const user = await User.findById(decoded.id).select("+mfaEnrollmentJti +mfaEnrollmentExpiresAt");
    if (!user || user.role !== USER_ROLES.ADMIN) {
      throw new ApiError(401, "Invalid MFA enrollment token.");
    }
    if (user.mfaEnabled) {
      throw new ApiError(409, "MFA is already enabled for this account.");
    }
    if (!user.mfaEnrollmentJti || decoded.jti !== user.mfaEnrollmentJti) {
      throw new ApiError(401, "MFA enrollment token is invalid or already used.");
    }
    if (!user.mfaEnrollmentExpiresAt || user.mfaEnrollmentExpiresAt.getTime() < Date.now()) {
      throw new ApiError(401, "MFA enrollment token has expired.");
    }

    req.user = user;
    req.mfaEnrollmentToken = token;
    req.mfaEnrollmentJti = decoded.jti;
    next();
  } catch (err) {
    if (err instanceof ApiError) return next(err);
    next(new ApiError(401, "Invalid or expired MFA enrollment token."));
  }
};

module.exports = mfaEnrollmentMiddleware;
