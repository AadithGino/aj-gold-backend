const express = require("express");
const authMiddleware = require("../middleware/auth.middleware");
const loginRateLimitMiddleware = require("../middleware/loginRateLimit.middleware");
const mfaEnrollmentMiddleware = require("../middleware/mfaEnrollment.middleware");
const { adminOnlyMiddleware } = require("../middleware/staffPermission.middleware");
const {
  loginController,
  completeMfaLoginController,
  meController,
  logoutController,
  beginMfaEnrollmentController,
  confirmMfaEnrollmentController,
  beginMfaEnrollmentBootstrapController,
  confirmMfaEnrollmentBootstrapController,
  disableMfaController,
  changePasswordController,
} = require("../controllers/auth.controller");

const router = express.Router();

router.post("/login", loginRateLimitMiddleware, loginController);
router.post("/mfa/complete-login", loginRateLimitMiddleware, completeMfaLoginController);
router.get("/me", authMiddleware, meController);
router.post("/logout", authMiddleware, logoutController);
router.post("/change-password", authMiddleware, changePasswordController);

router.post("/mfa/enroll-bootstrap", mfaEnrollmentMiddleware, beginMfaEnrollmentBootstrapController);
router.post("/mfa/confirm-bootstrap", mfaEnrollmentMiddleware, confirmMfaEnrollmentBootstrapController);

router.post("/mfa/enroll", authMiddleware, adminOnlyMiddleware, beginMfaEnrollmentController);
router.post("/mfa/confirm", authMiddleware, adminOnlyMiddleware, confirmMfaEnrollmentController);
router.post("/mfa/disable", authMiddleware, adminOnlyMiddleware, disableMfaController);

module.exports = router;
