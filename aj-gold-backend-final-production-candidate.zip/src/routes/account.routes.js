const express = require("express");
const authMiddleware = require("../middleware/auth.middleware");
const { customerOnlyMiddleware } = require("../middleware/staffPermission.middleware");
const {
  requestDeletionHandler,
  cancelDeletionHandler,
  getDeletionStatusHandler,
} = require("../controllers/accountDeletion.controller");

const router = express.Router();

router.use(authMiddleware);
router.use(customerOnlyMiddleware);

router.get("/deletion-status", getDeletionStatusHandler);
router.post("/deletion-requests", requestDeletionHandler);
router.post("/deletion-requests/:requestId/cancel", cancelDeletionHandler);

module.exports = router;
