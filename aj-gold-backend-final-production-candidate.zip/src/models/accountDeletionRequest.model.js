const mongoose = require("mongoose");
const { DELETION_REQUEST_STATUS } = require("../constants/enums");

const accountDeletionRequestSchema = new mongoose.Schema(
  {
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    status: {
      type: String,
      enum: Object.values(DELETION_REQUEST_STATUS),
      default: DELETION_REQUEST_STATUS.PENDING,
    },
    reason: { type: String, trim: true, default: "" },
    adminNotes: { type: String, trim: true, default: "" },
    blockReasons: { type: [String], default: [] },
    retentionDecision: { type: String, trim: true, default: "" },
    requestedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    reviewedAt: { type: Date },
    executedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    executedAt: { type: Date },
    idempotencyKey: { type: String, trim: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("AccountDeletionRequest", accountDeletionRequestSchema);
