const { login, me, logout, completeMfaLogin } = require("../services/auth.service");
const {
  beginMfaEnrollment,
  confirmMfaEnrollment,
  beginMfaEnrollmentBootstrap,
  confirmMfaEnrollmentBootstrap,
  disableMfa,
  changePrivilegedPassword,
} = require("../services/adminMfa.service");
const asyncHandler = require("../utils/asyncHandler");

const loginController = asyncHandler(async (req, res) => {
  const result = await login(req.body, { ip: req.clientIp || req.ip });
  res.json({ success: true, data: result });
});

const completeMfaLoginController = asyncHandler(async (req, res) => {
  const result = await completeMfaLogin(req.body, { ip: req.clientIp || req.ip });
  res.json({ success: true, data: result });
});

const meController = asyncHandler(async (req, res) => {
  const data = await me(req.user);
  res.json({ success: true, data });
});

const logoutController = asyncHandler(async (req, res) => {
  const data = await logout(req.user);
  res.json({ success: true, data });
});

const beginMfaEnrollmentController = asyncHandler(async (req, res) => {
  const data = await beginMfaEnrollment(req.user);
  res.json({ success: true, data });
});

const confirmMfaEnrollmentController = asyncHandler(async (req, res) => {
  const data = await confirmMfaEnrollment(req.user, req.body);
  res.json({ success: true, data });
});

const beginMfaEnrollmentBootstrapController = asyncHandler(async (req, res) => {
  const data = await beginMfaEnrollmentBootstrap(req.user);
  res.json({ success: true, data });
});

const confirmMfaEnrollmentBootstrapController = asyncHandler(async (req, res) => {
  const data = await confirmMfaEnrollmentBootstrap(req.user, req.body, req.mfaEnrollmentJti);
  res.json({ success: true, data });
});

const disableMfaController = asyncHandler(async (req, res) => {
  const data = await disableMfa(req.user, req.body);
  res.json({ success: true, data });
});

const changePasswordController = asyncHandler(async (req, res) => {
  const data = await changePrivilegedPassword(req.user, req.body);
  res.json({ success: true, data });
});

module.exports = {
  loginController,
  completeMfaLoginController,
  meController,
  logoutController,
  beginMfaEnrollmentController,
  confirmMfaEnrollmentController,
  beginMfaEnrollmentBootstrapController,
  confirmMfaEnrollmentBootstrapController,
  disableMfaController,
  changePasswordController,
};
