const { z } = require("zod");
const {
  requestDeletion,
  cancelDeletion,
  getCustomerDeletionStatus,
} = require("../services/accountDeletion.service");
const ApiError = require("../utils/ApiError");
const asyncHandler = require("../utils/asyncHandler");

const requestSchema = z.object({
  reason: z.string().trim().optional(),
  idempotencyKey: z.string().trim().optional(),
});

const parseBody = (schema, body) => {
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    throw new ApiError(400, parsed.error.issues[0]?.message || "Invalid request body.");
  }
  return parsed.data;
};

const requestDeletionHandler = asyncHandler(async (req, res) => {
  const payload = parseBody(requestSchema, req.body);
  const request = await requestDeletion(req.user, payload);
  return res.status(201).json({ success: true, data: request });
});

const cancelDeletionHandler = asyncHandler(async (req, res) => {
  const request = await cancelDeletion(req.user, req.params.requestId);
  return res.status(200).json({ success: true, data: request });
});

const getDeletionStatusHandler = asyncHandler(async (req, res) => {
  const status = await getCustomerDeletionStatus(req.user);
  return res.status(200).json({ success: true, data: status });
});

module.exports = {
  requestDeletionHandler,
  cancelDeletionHandler,
  getDeletionStatusHandler,
};
