const { z } = require("zod");
const {
  listDeletionRequests,
  getDeletionRequest,
  reviewDeletion,
  executeDeletion,
} = require("../services/accountDeletion.service");
const ApiError = require("../utils/ApiError");
const asyncHandler = require("../utils/asyncHandler");

const reviewSchema = z.object({
  decision: z.enum(["approve", "reject"]),
  adminNotes: z.string().trim().optional(),
  retentionDecision: z.string().trim().optional(),
});

const executeSchema = z.object({
  idempotencyKey: z.string().trim().optional(),
});

const parseBody = (schema, body) => {
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    throw new ApiError(400, parsed.error.issues[0]?.message || "Invalid request body.");
  }
  return parsed.data;
};

const listDeletionRequestsHandler = asyncHandler(async (req, res) => {
  const items = await listDeletionRequests({ status: req.query.status });
  return res.status(200).json({ success: true, data: { items } });
});

const getDeletionRequestHandler = asyncHandler(async (req, res) => {
  const request = await getDeletionRequest(req.params.requestId);
  return res.status(200).json({ success: true, data: request });
});

const reviewDeletionHandler = asyncHandler(async (req, res) => {
  const payload = parseBody(reviewSchema, req.body);
  const request = await reviewDeletion(req.user, req.params.requestId, payload);
  return res.status(200).json({ success: true, data: request });
});

const executeDeletionHandler = asyncHandler(async (req, res) => {
  const payload = parseBody(executeSchema, req.body);
  const request = await executeDeletion(req.user, req.params.requestId, payload);
  return res.status(200).json({ success: true, data: request });
});

module.exports = {
  listDeletionRequestsHandler,
  getDeletionRequestHandler,
  reviewDeletionHandler,
  executeDeletionHandler,
};
