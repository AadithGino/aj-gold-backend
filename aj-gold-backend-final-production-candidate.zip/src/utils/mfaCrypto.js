const crypto = require("crypto");
const { MFA_ENCRYPTION_KEY, NODE_ENV } = require("../config/env");

const PREFIX = "enc:v1:";

const getKey = () => {
  if (!MFA_ENCRYPTION_KEY) {
    if (NODE_ENV === "production") {
      throw new Error("MFA_ENCRYPTION_KEY is required in production.");
    }
    return null;
  }
  return crypto.createHash("sha256").update(MFA_ENCRYPTION_KEY).digest();
};

const encryptSecret = (plaintext) => {
  const key = getKey();
  if (!key || !plaintext) {
    return plaintext;
  }

  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(String(plaintext), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${PREFIX}${iv.toString("base64url")}.${tag.toString("base64url")}.${encrypted.toString("base64url")}`;
};

const decryptSecret = (stored) => {
  if (!stored || !String(stored).startsWith(PREFIX)) {
    return stored;
  }

  const key = getKey();
  if (!key) {
    throw new Error("Encrypted MFA secret cannot be read without MFA_ENCRYPTION_KEY.");
  }

  const payload = String(stored).slice(PREFIX.length);
  const [ivPart, tagPart, dataPart] = payload.split(".");
  const decipher = crypto.createDecipheriv(
    "aes-256-gcm",
    key,
    Buffer.from(ivPart, "base64url")
  );
  decipher.setAuthTag(Buffer.from(tagPart, "base64url"));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(dataPart, "base64url")),
    decipher.final(),
  ]);
  return decrypted.toString("utf8");
};

module.exports = {
  encryptSecret,
  decryptSecret,
};
