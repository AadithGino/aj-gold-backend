const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const AccountDeletionRequest = require("../models/accountDeletionRequest.model");
const Customer = require("../models/customer.model");
const User = require("../models/user.model");
const Scheme = require("../models/scheme.model");
const FinancialJournal = require("../models/financialJournal.model");
const ApiError = require("../utils/ApiError");
const { withTransaction } = require("../utils/transaction");
const { logAudit } = require("./audit.service");
const {
  AUDIT_ACTIONS,
  DELETION_REQUEST_STATUS,
  SCHEME_STATUS,
  SETTLEMENT_WORKFLOW_STATUS,
  USER_ROLES,
  USER_STATUS,
} = require("../constants/enums");

const sanitizeDeletionRequest = (request) => ({
  _id: request._id,
  customer: request.customer,
  user: request.user,
  status: request.status,
  reason: request.reason || "",
  adminNotes: request.adminNotes || "",
  blockReasons: request.blockReasons || [],
  retentionDecision: request.retentionDecision || "",
  requestedBy: request.requestedBy,
  reviewedBy: request.reviewedBy,
  reviewedAt: request.reviewedAt,
  executedBy: request.executedBy,
  executedAt: request.executedAt,
  createdAt: request.createdAt,
  updatedAt: request.updatedAt,
});

const getCustomerForUser = async (userId) => {
  const customer = await Customer.findOne({ user: userId });
  if (!customer) {
    throw new ApiError(404, "Customer profile not found.");
  }
  return customer;
};

const evaluateDeletionBlocks = async (customerId) => {
  const blockReasons = [];
  const customer = await Customer.findById(customerId);
  if (!customer) {
    throw new ApiError(404, "Customer not found.");
  }

  if (customer.legalHold) {
    blockReasons.push("LEGAL_HOLD");
  }

  const activeScheme = await Scheme.findOne({
    customer: customerId,
    status: SCHEME_STATUS.ACTIVE,
  });
  if (activeScheme) {
    blockReasons.push("ACTIVE_SCHEME");
  }

  const unsettledSchemes = await Scheme.find({
    customer: customerId,
    status: { $in: [SCHEME_STATUS.REDEEMED, SCHEME_STATUS.CLOSED] },
    "settlementWorkflow.status": {
      $nin: [SETTLEMENT_WORKFLOW_STATUS.FINALIZED, SETTLEMENT_WORKFLOW_STATUS.CANCELLED],
    },
  });
  if (unsettledSchemes.length) {
    blockReasons.push("UNSETTLED_ENTITLEMENT");
  }

  const pendingSettlement = await Scheme.findOne({
    customer: customerId,
    "settlementWorkflow.status": {
      $in: [
        SETTLEMENT_WORKFLOW_STATUS.REQUESTED,
        SETTLEMENT_WORKFLOW_STATUS.APPROVED,
        SETTLEMENT_WORKFLOW_STATUS.PAYOUT_PENDING,
        SETTLEMENT_WORKFLOW_STATUS.PAID,
      ],
    },
  });
  if (pendingSettlement) {
    blockReasons.push("PENDING_SETTLEMENT");
  }

  return blockReasons;
};

const requestDeletion = async (actor, { reason = "", idempotencyKey } = {}) => {
  if (actor.role !== USER_ROLES.CUSTOMER) {
    throw new ApiError(403, "Only customers can request account deletion.");
  }

  const customer = await getCustomerForUser(actor._id);
  if (customer.anonymized) {
    throw new ApiError(409, "Account has already been anonymized.");
  }

  if (idempotencyKey) {
    const existing = await AccountDeletionRequest.findOne({ idempotencyKey: idempotencyKey.trim() });
    if (existing) {
      if (String(existing.customer) !== String(customer._id)) {
        throw new ApiError(409, "Idempotency key is already associated with another account.", [], {
          retryable: false,
        });
      }
      return sanitizeDeletionRequest(existing);
    }
  }

  const blockReasons = await evaluateDeletionBlocks(customer._id);
  const existingPending = await AccountDeletionRequest.findOne({
    customer: customer._id,
    status: DELETION_REQUEST_STATUS.PENDING,
  });
  if (existingPending) {
    return sanitizeDeletionRequest(existingPending);
  }

  const [request] = await AccountDeletionRequest.create([
    {
      customer: customer._id,
      user: customer.user,
      requestedBy: actor._id,
      reason: reason.trim(),
      blockReasons,
      idempotencyKey: idempotencyKey?.trim() || undefined,
    },
  ]);

  await logAudit({
    actor: actor._id,
    actorRole: actor.role,
    action: AUDIT_ACTIONS.DELETION_REQUESTED,
    targetType: "AccountDeletionRequest",
    targetId: request._id,
    newValue: sanitizeDeletionRequest(request),
    notes: blockReasons.length ? "Deletion requested with block reasons" : "Deletion requested",
  });

  return sanitizeDeletionRequest(request);
};

const cancelDeletion = async (actor, requestId) => {
  const customer = await getCustomerForUser(actor._id);
  const request = await AccountDeletionRequest.findOne({
    _id: requestId,
    customer: customer._id,
  });
  if (!request) {
    throw new ApiError(404, "Deletion request not found.");
  }
  if (request.status !== DELETION_REQUEST_STATUS.PENDING) {
    throw new ApiError(409, "Only pending deletion requests can be cancelled.");
  }

  request.status = DELETION_REQUEST_STATUS.CANCELLED;
  await request.save();

  await logAudit({
    actor: actor._id,
    actorRole: actor.role,
    action: AUDIT_ACTIONS.DELETION_CANCELLED,
    targetType: "AccountDeletionRequest",
    targetId: request._id,
    notes: "Deletion request cancelled by customer",
  });

  return sanitizeDeletionRequest(request);
};

const listDeletionRequests = async ({ status } = {}) => {
  const query = status ? { status } : {};
  const items = await AccountDeletionRequest.find(query)
    .sort({ createdAt: -1 })
    .populate("customer", "name passbookNumber phone status anonymized")
    .limit(200);
  return items.map(sanitizeDeletionRequest);
};

const getDeletionRequest = async (requestId) => {
  const request = await AccountDeletionRequest.findById(requestId).populate(
    "customer",
    "name passbookNumber phone status anonymized legalHold"
  );
  if (!request) {
    throw new ApiError(404, "Deletion request not found.");
  }
  const blockReasons = await evaluateDeletionBlocks(request.customer._id || request.customer);
  return {
    ...sanitizeDeletionRequest(request),
    currentBlockReasons: blockReasons,
  };
};

const reviewDeletion = async (actor, requestId, { decision, adminNotes = "", retentionDecision = "" }) => {
  const request = await AccountDeletionRequest.findById(requestId);
  if (!request) {
    throw new ApiError(404, "Deletion request not found.");
  }
  if (request.status !== DELETION_REQUEST_STATUS.PENDING) {
    throw new ApiError(409, "Deletion request is not pending review.");
  }

  if (decision === "reject") {
    request.status = DELETION_REQUEST_STATUS.REJECTED;
    request.adminNotes = adminNotes.trim();
    request.reviewedBy = actor._id;
    request.reviewedAt = new Date();
    await request.save();

    await logAudit({
      actor: actor._id,
      actorRole: actor.role,
      action: AUDIT_ACTIONS.DELETION_REJECTED,
      targetType: "AccountDeletionRequest",
      targetId: request._id,
      notes: adminNotes.trim() || "Deletion rejected",
    });

    return sanitizeDeletionRequest(request);
  }

  if (decision !== "approve") {
    throw new ApiError(400, "Decision must be approve or reject.");
  }

  const blockReasons = await evaluateDeletionBlocks(request.customer);
  if (blockReasons.length) {
    throw new ApiError(409, "Deletion cannot be approved while blocking financial state exists.", [], {
      blockReasons,
    });
  }

  request.status = DELETION_REQUEST_STATUS.APPROVED;
  request.adminNotes = adminNotes.trim();
  request.retentionDecision = retentionDecision.trim() || "RETAIN_FINANCIAL_JOURNAL_AND_AUDIT";
  request.reviewedBy = actor._id;
  request.reviewedAt = new Date();
  await request.save();

  await logAudit({
    actor: actor._id,
    actorRole: actor.role,
    action: AUDIT_ACTIONS.DELETION_APPROVED,
    targetType: "AccountDeletionRequest",
    targetId: request._id,
    notes: adminNotes.trim() || "Deletion approved",
  });

  return sanitizeDeletionRequest(request);
};

const anonymizeCustomerRecords = async ({ customer, actor, session }) => {
  const suffix = crypto.randomBytes(4).toString("hex");
  const deletedPhone = `deleted-${customer._id.toString().slice(-6)}-${suffix}`;
  const deletedName = "Deleted Customer";

  customer.name = deletedName;
  customer.phone = deletedPhone;
  customer.address = "";
  customer.nominee = {};
  customer.status = USER_STATUS.INACTIVE;
  customer.anonymized = true;
  customer.anonymizedAt = new Date();
  customer.updatedBy = actor._id;
  await customer.save({ session });

  if (customer.user) {
    await User.findByIdAndUpdate(
      customer.user,
      {
        name: deletedName,
        phone: deletedPhone,
        status: USER_STATUS.INACTIVE,
        passwordHash: await bcrypt.hash(crypto.randomBytes(16).toString("hex"), 10),
        mfaEnabled: false,
        $unset: { mfaSecret: "", mfaRecoveryCodeHashes: "" },
        updatedBy: actor._id,
        $inc: { tokenVersion: 1 },
      },
      { session }
    );
  }
};

const executeDeletion = async (actor, requestId, { idempotencyKey } = {}) => {
  if (idempotencyKey) {
    const keyed = await AccountDeletionRequest.findOne({ idempotencyKey: idempotencyKey.trim() });
    if (keyed) {
      if (String(keyed._id) !== String(requestId)) {
        throw new ApiError(409, "Idempotency key is already associated with another deletion request.", [], {
          retryable: false,
        });
      }
      if (keyed.status === DELETION_REQUEST_STATUS.EXECUTED) {
        return sanitizeDeletionRequest(keyed);
      }
    }
  }

  const request = await AccountDeletionRequest.findById(requestId);
  if (!request) {
    throw new ApiError(404, "Deletion request not found.");
  }

  if (request.status === DELETION_REQUEST_STATUS.EXECUTED) {
    return sanitizeDeletionRequest(request);
  }

  if (request.status !== DELETION_REQUEST_STATUS.APPROVED) {
    throw new ApiError(409, "Deletion request must be approved before execution.");
  }

  const blockReasons = await evaluateDeletionBlocks(request.customer);
  if (blockReasons.length) {
    throw new ApiError(409, "Deletion cannot be executed while blocking financial state exists.", [], {
      blockReasons,
    });
  }

  const journalCount = await FinancialJournal.countDocuments({ customer: request.customer });

  await withTransaction(async (session) => {
    const customer = await Customer.findById(request.customer).session(session);
    if (!customer) {
      throw new ApiError(404, "Customer not found.");
    }

    await anonymizeCustomerRecords({ customer, actor, session });

    request.status = DELETION_REQUEST_STATUS.EXECUTED;
    request.executedBy = actor._id;
    request.executedAt = new Date();
    request.retentionDecision =
      request.retentionDecision || "RETAIN_FINANCIAL_JOURNAL_AND_AUDIT";
    if (idempotencyKey) {
      request.idempotencyKey = idempotencyKey.trim();
    }
    await request.save({ session });

    await logAudit({
      actor: actor._id,
      actorRole: actor.role,
      action: AUDIT_ACTIONS.DELETION_EXECUTED,
      targetType: "AccountDeletionRequest",
      targetId: request._id,
      newValue: {
        retentionDecision: request.retentionDecision,
        journalEntriesRetained: journalCount,
      },
      notes: "Deletion executed with financial retention",
      session,
    });

    await logAudit({
      actor: actor._id,
      actorRole: actor.role,
      action: AUDIT_ACTIONS.ACCOUNT_ANONYMIZED,
      targetType: "Customer",
      targetId: customer._id,
      notes: "Customer PII anonymized; financial journal retained",
      session,
    });
  });

  const saved = await AccountDeletionRequest.findById(requestId);
  return sanitizeDeletionRequest(saved);
};

const getCustomerDeletionStatus = async (actor) => {
  const customer = await getCustomerForUser(actor._id);
  const pending = await AccountDeletionRequest.findOne({
    customer: customer._id,
    status: DELETION_REQUEST_STATUS.PENDING,
  });
  const latest = await AccountDeletionRequest.findOne({ customer: customer._id }).sort({
    createdAt: -1,
  });
  return {
    customerId: customer._id,
    anonymized: Boolean(customer.anonymized),
    pendingRequest: pending ? sanitizeDeletionRequest(pending) : null,
    latestRequest: latest ? sanitizeDeletionRequest(latest) : null,
    currentBlockReasons: await evaluateDeletionBlocks(customer._id),
  };
};

module.exports = {
  requestDeletion,
  cancelDeletion,
  listDeletionRequests,
  getDeletionRequest,
  reviewDeletion,
  executeDeletion,
  getCustomerDeletionStatus,
  evaluateDeletionBlocks,
};
