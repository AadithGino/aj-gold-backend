const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const User = require("../models/user.model");
const Customer = require("../models/customer.model");
const { logAudit } = require("./audit.service");
const ApiError = require("../utils/ApiError");
const {
  JWT_SECRET,
  JWT_EXPIRES_IN,
  JWT_ISSUER,
  JWT_AUDIENCE,
  MFA_CHALLENGE_EXPIRES_IN,
  ADMIN_MFA_REQUIRED,
} = require("../config/env");
const { AUDIT_ACTIONS, USER_ROLES } = require("../constants/enums");
const { assertPrivilegedPassword } = require("../constants/credentialPolicies");
const {
  assertNotLocked,
  recordFailedAttempt,
  resetAttempts,
} = require("./loginRateLimit.service");
const { verifyMfaChallenge, issueMfaEnrollmentCredential } = require("./adminMfa.service");

const signAccessToken = (user) =>
  jwt.sign(
    {
      id: user._id,
      role: user.role,
      tokenVersion: user.tokenVersion || 0,
    },
    JWT_SECRET,
    {
      expiresIn: JWT_EXPIRES_IN,
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE,
    }
  );

const signMfaChallengeToken = (user) =>
  jwt.sign(
    {
      id: user._id,
      role: user.role,
      purpose: "mfa-challenge",
    },
    JWT_SECRET,
    {
      expiresIn: MFA_CHALLENGE_EXPIRES_IN,
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE,
    }
  );

const verifyMfaChallengeToken = (token) => {
  const decoded = jwt.verify(token, JWT_SECRET, {
    issuer: JWT_ISSUER,
    audience: JWT_AUDIENCE,
  });
  if (decoded.purpose !== "mfa-challenge") {
    throw new ApiError(401, "Invalid MFA challenge token.");
  }
  return decoded;
};

const generateTemporaryPassword = () =>
  crypto.randomBytes(9).toString("base64url").slice(0, 12);

const buildAuthResponse = (user) => ({
  token: signAccessToken(user),
  user: {
    _id: user._id,
    name: user.name,
    phone: user.phone,
    role: user.role,
    status: user.status,
    mustChangePassword: Boolean(user.mustChangePassword),
    mfaEnabled: Boolean(user.mfaEnabled),
  },
});

const login = async ({ phone, password }, { ip } = {}) => {
  if (!phone?.trim() || !password) {
    throw new ApiError(400, "Phone and password are required.");
  }

  const normalizedPhone = phone.trim();
  await assertNotLocked({ ip, phone: normalizedPhone });

  const user = await User.findOne({ phone: normalizedPhone }).select(
    "name phone role status tokenVersion mustChangePassword mfaEnabled +passwordHash"
  );
  if (!user) {
    await recordFailedAttempt({ ip, phone: normalizedPhone });
    throw new ApiError(401, "Invalid phone or password.");
  }
  if (user.status === "INACTIVE") throw new ApiError(403, "Account is inactive.");
  if (!user.passwordHash) {
    await recordFailedAttempt({ ip, phone: normalizedPhone });
    throw new ApiError(401, "Invalid phone or password.");
  }

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) {
    await recordFailedAttempt({ ip, phone: normalizedPhone });
    throw new ApiError(401, "Invalid phone or password.");
  }

  await resetAttempts({ ip, phone: normalizedPhone });

  if (
    user.role === USER_ROLES.ADMIN &&
    ADMIN_MFA_REQUIRED &&
    user.mfaEnabled
  ) {
    return {
      mfaRequired: true,
      mfaChallengeToken: signMfaChallengeToken(user),
      user: {
        _id: user._id,
        name: user.name,
        phone: user.phone,
        role: user.role,
      },
    };
  }

  if (
    user.role === USER_ROLES.ADMIN &&
    ADMIN_MFA_REQUIRED &&
    !user.mfaEnabled
  ) {
    const enrollment = await issueMfaEnrollmentCredential(user);
    return {
      mfaEnrollmentRequired: true,
      mfaEnrollmentToken: enrollment.token,
      user: {
        _id: user._id,
        name: user.name,
        phone: user.phone,
        role: user.role,
      },
    };
  }

  await User.updateOne({ _id: user._id }, { $set: { lastLoginAt: new Date() } });

  await logAudit({
    actor: user._id,
    actorRole: user.role,
    action: AUDIT_ACTIONS.LOGIN,
    targetType: "User",
    targetId: user._id,
    notes: "User logged in",
  });

  return buildAuthResponse(user);
};

const completeMfaLogin = async ({ mfaChallengeToken, code, recoveryCode }, { ip } = {}) => {
  const decoded = verifyMfaChallengeToken(mfaChallengeToken);
  const account = await User.findById(decoded.id).select("phone");

  try {
    const user = await verifyMfaChallenge(decoded.id, { code, recoveryCode });
    await resetAttempts({ ip, phone: user.phone });
    await User.updateOne({ _id: user._id }, { $set: { lastLoginAt: new Date() } });

    await logAudit({
      actor: user._id,
      actorRole: user.role,
      action: AUDIT_ACTIONS.LOGIN,
      targetType: "User",
      targetId: user._id,
      notes: "Admin logged in with MFA",
    });

    return buildAuthResponse(user);
  } catch (error) {
    if (account?.phone) {
      await recordFailedAttempt({ ip, phone: account.phone });
    }
    throw error;
  }
};

const logout = async (user) => {
  await User.updateOne({ _id: user._id }, { $inc: { tokenVersion: 1 } });
  await logAudit({
    actor: user._id,
    actorRole: user.role,
    action: AUDIT_ACTIONS.LOGOUT,
    targetType: "User",
    targetId: user._id,
    notes: "User logged out",
  });
  return { message: "Logged out successfully." };
};

const me = async (user) => ({
  user: {
    _id: user._id,
    name: user.name,
    phone: user.phone,
    role: user.role,
    status: user.status,
    mustChangePassword: Boolean(user.mustChangePassword),
    mfaEnabled: Boolean(user.mfaEnabled),
  },
});

const assertPasswordStrength = assertPrivilegedPassword;

module.exports = {
  login,
  completeMfaLogin,
  logout,
  me,
  assertPasswordStrength,
  generateTemporaryPassword,
  signAccessToken,
  verifyMfaChallengeToken,
};
