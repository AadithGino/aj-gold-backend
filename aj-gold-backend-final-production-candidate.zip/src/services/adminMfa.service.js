const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/user.model");
const ApiError = require("../utils/ApiError");
const { logAudit } = require("./audit.service");
const { AUDIT_ACTIONS, USER_ROLES } = require("../constants/enums");
const { assertPrivilegedPassword } = require("../constants/credentialPolicies");
const {
  JWT_SECRET,
  JWT_ISSUER,
  JWT_AUDIENCE,
  MFA_ENROLLMENT_EXPIRES_IN,
} = require("../config/env");
const { encryptSecret, decryptSecret } = require("../utils/mfaCrypto");

const RECOVERY_CODE_COUNT = 8;
const TOTP_STEP_SECONDS = 30;
const TOTP_DIGITS = 6;

const base32Encode = (buffer) => {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = 0;
  let value = 0;
  let output = "";

  for (const byte of buffer) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }

  if (bits > 0) {
    output += alphabet[(value << (5 - bits)) & 31];
  }

  return output;
};

const generateMfaSecret = () => base32Encode(crypto.randomBytes(20));

const decodeBase32 = (input) => {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const normalized = String(input || "")
    .toUpperCase()
    .replace(/=+$/, "");
  let bits = 0;
  let value = 0;
  const bytes = [];

  for (const char of normalized) {
    const index = alphabet.indexOf(char);
    if (index === -1) continue;
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }

  return Buffer.from(bytes);
};

const generateTotp = (secret, counter) => {
  const key = decodeBase32(secret);
  const buffer = Buffer.alloc(8);
  buffer.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac("sha1", key).update(buffer).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  return String(code % 10 ** TOTP_DIGITS).padStart(TOTP_DIGITS, "0");
};

const getCurrentTotp = (secret) =>
  generateTotp(secret, Math.floor(Date.now() / 1000 / TOTP_STEP_SECONDS));

const verifyTotp = (secret, token, { window = 1 } = {}) => {
  const normalized = String(token || "").trim();
  if (!/^\d{6}$/.test(normalized)) return false;
  const counter = Math.floor(Date.now() / 1000 / TOTP_STEP_SECONDS);
  for (let offset = -window; offset <= window; offset += 1) {
    if (generateTotp(secret, counter + offset) === normalized) {
      return true;
    }
  }
  return false;
};

const generateRecoveryCodes = async () => {
  const codes = Array.from({ length: RECOVERY_CODE_COUNT }, () =>
    crypto.randomBytes(5).toString("hex").slice(0, 10)
  );
  const hashes = await Promise.all(codes.map((code) => bcrypt.hash(code, 10)));
  return { codes, hashes };
};

const getStoredMfaSecret = (user) => decryptSecret(user.mfaSecret);

const setStoredMfaSecret = (user, secret) => {
  user.mfaSecret = encryptSecret(secret);
};

const signMfaEnrollmentToken = (user, jti) =>
  jwt.sign(
    {
      id: user._id,
      role: user.role,
      purpose: "mfa-enrollment",
      jti,
    },
    JWT_SECRET,
    {
      expiresIn: MFA_ENROLLMENT_EXPIRES_IN,
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE,
    }
  );

const issueMfaEnrollmentCredential = async (user) => {
  const jti = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

  await User.updateOne(
    { _id: user._id, mfaEnabled: false },
    {
      $set: {
        mfaEnrollmentJti: jti,
        mfaEnrollmentExpiresAt: expiresAt,
      },
    }
  );

  return {
    token: signMfaEnrollmentToken(user, jti),
    expiresAt,
  };
};

const consumeMfaEnrollmentCredential = async (userId, jti) => {
  const consumed = await User.findOneAndUpdate(
    {
      _id: userId,
      mfaEnrollmentJti: jti,
      mfaEnrollmentExpiresAt: { $gt: new Date() },
    },
    {
      $unset: {
        mfaEnrollmentJti: "",
        mfaEnrollmentExpiresAt: "",
      },
    },
    { new: false }
  );

  if (!consumed) {
    throw new ApiError(401, "MFA enrollment token is invalid or already used.");
  }

  return consumed;
};

const assertAdminActor = (actor) => {
  if (!actor || actor.role !== USER_ROLES.ADMIN) {
    throw new ApiError(403, "Admin access required.");
  }
};

const beginMfaEnrollment = async (actor) => {
  assertAdminActor(actor);
  const user = await User.findById(actor._id).select("+mfaSecret +mfaRecoveryCodeHashes");
  if (!user) throw new ApiError(404, "User not found.");

  const secret = generateMfaSecret();
  setStoredMfaSecret(user, secret);
  user.mfaEnabled = false;
  await user.save();

  return {
    secret,
    otpauthUrl: `otpauth://totp/AJGold:${encodeURIComponent(user.phone)}?secret=${secret}&issuer=AJGold`,
  };
};

const beginMfaEnrollmentBootstrap = async (actor) => beginMfaEnrollment(actor);

const confirmMfaEnrollment = async (actor, { code, recoveryCodesAcknowledged = false }) => {
  assertAdminActor(actor);
  if (!recoveryCodesAcknowledged) {
    throw new ApiError(400, "Recovery code acknowledgement is required.");
  }

  const user = await User.findById(actor._id).select("+mfaSecret +mfaRecoveryCodeHashes");
  if (!user?.mfaSecret) {
    throw new ApiError(400, "MFA enrollment has not started.");
  }
  if (!verifyTotp(getStoredMfaSecret(user), code)) {
    throw new ApiError(400, "Invalid MFA code.");
  }

  const { codes, hashes } = await generateRecoveryCodes();
  user.mfaEnabled = true;
  user.mfaRecoveryCodeHashes = hashes;
  await user.save();

  await logAudit({
    actor: actor._id,
    actorRole: actor.role,
    action: AUDIT_ACTIONS.MFA_ENROLLED,
    targetType: "User",
    targetId: actor._id,
    notes: "Admin MFA enrolled",
  });

  return { recoveryCodes: codes };
};

const confirmMfaEnrollmentBootstrap = async (actor, payload, enrollmentJti) => {
  const result = await confirmMfaEnrollment(actor, payload);
  await consumeMfaEnrollmentCredential(actor._id, enrollmentJti);
  return {
    ...result,
    loginRequired: true,
  };
};

const disableMfa = async (actor, { code }) => {
  assertAdminActor(actor);
  const user = await User.findById(actor._id).select("+mfaSecret +mfaRecoveryCodeHashes");
  if (!user?.mfaEnabled || !user.mfaSecret) {
    throw new ApiError(400, "MFA is not enabled.");
  }
  if (!verifyTotp(getStoredMfaSecret(user), code)) {
    throw new ApiError(400, "Invalid MFA code.");
  }

  user.mfaEnabled = false;
  user.mfaSecret = undefined;
  user.mfaRecoveryCodeHashes = [];
  await user.save();

  await logAudit({
    actor: actor._id,
    actorRole: actor.role,
    action: AUDIT_ACTIONS.MFA_DISABLED,
    targetType: "User",
    targetId: actor._id,
    notes: "Admin MFA disabled",
  });

  return { success: true };
};

const verifyMfaChallenge = async (userId, { code, recoveryCode }) => {
  const user = await User.findById(userId).select("+mfaSecret +mfaRecoveryCodeHashes");
  if (!user?.mfaEnabled || !user.mfaSecret) {
    throw new ApiError(400, "MFA is not enabled for this account.");
  }

  const secret = getStoredMfaSecret(user);
  if (code && verifyTotp(secret, code)) {
    return user;
  }

  if (recoveryCode) {
    const updated = await User.findOneAndUpdate(
      { _id: userId, mfaEnabled: true },
      {},
      { new: true }
    ).select("+mfaSecret +mfaRecoveryCodeHashes");

    if (!updated?.mfaSecret) {
      throw new ApiError(400, "MFA is not enabled for this account.");
    }

    for (let index = 0; index < updated.mfaRecoveryCodeHashes.length; index += 1) {
      const match = await bcrypt.compare(recoveryCode, updated.mfaRecoveryCodeHashes[index]);
      if (match) {
        updated.mfaRecoveryCodeHashes.splice(index, 1);
        await updated.save();
        return updated;
      }
    }
  }

  await logAudit({
    actor: user._id,
    actorRole: user.role,
    action: AUDIT_ACTIONS.MFA_CHALLENGE_FAILED,
    targetType: "User",
    targetId: user._id,
    notes: "MFA challenge failed",
  });

  throw new ApiError(401, "Invalid MFA code.");
};

const changePrivilegedPassword = async (actor, { currentPassword, newPassword }) => {
  if (![USER_ROLES.ADMIN, USER_ROLES.STAFF].includes(actor.role)) {
    throw new ApiError(403, "Only privileged users can change password here.");
  }

  assertPrivilegedPassword(newPassword);
  const user = await User.findById(actor._id).select("+passwordHash");
  if (!user?.passwordHash) {
    throw new ApiError(400, "Password is not set.");
  }

  const match = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!match) {
    throw new ApiError(401, "Current password is incorrect.");
  }

  user.passwordHash = await bcrypt.hash(newPassword, 10);
  user.mustChangePassword = false;
  user.tokenVersion = (user.tokenVersion || 0) + 1;
  await user.save();

  await logAudit({
    actor: actor._id,
    actorRole: actor.role,
    action: AUDIT_ACTIONS.PASSWORD_RESET,
    targetType: "User",
    targetId: actor._id,
    notes: "Privileged password changed",
  });

  return { success: true };
};

module.exports = {
  beginMfaEnrollment,
  beginMfaEnrollmentBootstrap,
  confirmMfaEnrollment,
  confirmMfaEnrollmentBootstrap,
  disableMfa,
  verifyMfaChallenge,
  verifyTotp,
  getCurrentTotp,
  changePrivilegedPassword,
  generateMfaSecret,
  issueMfaEnrollmentCredential,
  consumeMfaEnrollmentCredential,
};
